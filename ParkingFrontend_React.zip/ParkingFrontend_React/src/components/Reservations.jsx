import React, {useEffect, useState} from 'react'
import axios from 'axios'

export default function Reservations(){
  const [reservations, setReservations] = useState([])
  const [plate, setPlate] = useState('')
  const [placeId, setPlaceId] = useState('')
  const [places, setPlaces] = useState([])

  const fetchReservations = async () => {
    try{
      const res = await axios.get('/api/reservations')
      setReservations(res.data)
    }catch(e){
      alert('Error al cargar reservas: '+e.message)
    }
  }

  const fetchPlaces = async () => {
    try{
      const res = await axios.get('/api/places')
      setPlaces(res.data.filter(p=>!p.occupied))
    }catch(e){
      console.log(e)
    }
  }

  useEffect(()=>{
    fetchReservations()
    fetchPlaces()
  },[])

  const createReservation = async () => {
    if(!plate || !placeId){ alert('Ingrese placa y plaza'); return}
    try{
      await axios.post(`/api/reservations?plate=${encodeURIComponent(plate)}&placeId=${placeId}`)
      setPlate('')
      setPlaceId('')
      fetchReservations()
      fetchPlaces()
    }catch(e){
      alert('Error creando reserva: '+(e.response?.data?.message || e.message))
    }
  }

  const finishReservation = async (id) => {
    try{
      await axios.post(`/api/reservations/${id}/finish`)
      fetchReservations()
      fetchPlaces()
    }catch(e){
      alert('Error finalizando reserva: '+e.message)
    }
  }

  return (
    <div>
      <h2>Reservas</h2>
      <div className="form">
        <input value={plate} onChange={e=>setPlate(e.target.value)} placeholder="Placa"/>
        <select value={placeId} onChange={e=>setPlaceId(e.target.value)}>
          <option value="">Seleccione plaza</option>
          {places.map(p=> <option key={p.id} value={p.id}>{p.code}</option>)}
        </select>
        <button className="button primary" onClick={createReservation}>Reservar</button>
      </div>

      <div>
        {reservations.length===0 && <p>No hay reservas</p>}
        {reservations.map(r=>(
          <div key={r.id} className="place">
            <div>
              <strong>{r.plate}</strong> - {r.place?.code || 'N/A'} <br/>
              Inicio: {r.startTime ? new Date(r.startTime).toLocaleString() : '-'} <br/>
              Fin: {r.endTime ? new Date(r.endTime).toLocaleString() : '-'}
            </div>
            <div>
              {!r.endTime && <button className="button danger" onClick={()=>finishReservation(r.id)}>Finalizar</button>}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
