import React, {useEffect, useState} from 'react'
import axios from 'axios'

export default function Places(){
  const [places, setPlaces] = useState([])
  const [loading, setLoading] = useState(false)
  const [code, setCode] = useState('C1')

  const fetchPlaces = async () => {
    setLoading(true)
    try{
      const res = await axios.get('/api/places')
      setPlaces(res.data)
    }catch(e){
      alert('Error al cargar plazas: '+e.message)
    }finally{setLoading(false)}
  }

  useEffect(()=>{ fetchPlaces() }, [])

  const createPlace = async () => {
    try{
      await axios.post('/api/places', { code, occupied:false })
      setCode('')
      fetchPlaces()
    }catch(e){
      alert('Error creando plaza: '+e.message)
    }
  }

  return (
    <div>
      <h2>Plazas</h2>
      <div className="form">
        <input value={code} onChange={e=>setCode(e.target.value)} placeholder="Código"/>
        <button className="button primary" onClick={createPlace}>Crear plaza</button>
        <button className="button" onClick={fetchPlaces}>Recargar</button>
      </div>
      {loading ? <p>Cargando...</p> : places.map(p=>(
        <div key={p.id} className="place">
          <div>
            <strong>{p.code}</strong> {p.occupied ? <span>(ocupada)</span> : <span>(libre)</span>}
          </div>
          <div>
            {/* placeholder for actions */}
          </div>
        </div>
      ))}
    </div>
  )
}
