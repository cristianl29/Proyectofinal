import React from 'react'
import Places from './components/Places'
import Reservations from './components/Reservations'

export default function App(){
  return (
    <div className="app">
      <header>
        <h1>Parking - Demo Frontend</h1>
        <p>Consume endpoints del backend (http://localhost:8080)</p>
      </header>
      <main>
        <div className="column">
          <Places />
        </div>
        <div className="column">
          <Reservations />
        </div>
      </main>
      <footer>
        <small>Proyecto para entrega - Backend Java + H2</small>
      </footer>
    </div>
  )
}
