package edu.university.parking.controller;

import edu.university.parking.model.Reservation;
import edu.university.parking.service.ReservationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {
    private final ReservationService service;

    public ReservationController(ReservationService service) {
        this.service = service;
    }

    @GetMapping
    public List<Reservation> all() {
        return service.listAll();
    }

    @GetMapping("/<built-in function id>")
    public ResponseEntity<Reservation> get(@PathVariable Long id) {
        return service.get(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Reservation create(@RequestParam String plate, @RequestParam Long placeId) {
        return service.create(plate, placeId);
    }

    @PostMapping("/<built-in function id>/finish")
    public Reservation finish(@PathVariable Long id) {
        return service.finish(id);
    }
}
