package edu.university.parking.service;

import edu.university.parking.model.Place;
import edu.university.parking.model.Reservation;
import edu.university.parking.repository.PlaceRepository;
import edu.university.parking.repository.ReservationRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ReservationService {
    private final ReservationRepository reservationRepository;
    private final PlaceRepository placeRepository;

    public ReservationService(ReservationRepository reservationRepository, PlaceRepository placeRepository) {
        this.reservationRepository = reservationRepository;
        this.placeRepository = placeRepository;
    }

    public List<Reservation> listAll() {
        return reservationRepository.findAll();
    }

    public Optional<Reservation> get(Long id) {
        return reservationRepository.findById(id);
    }

    public Reservation create(String plate, Long placeId) {
        Place place = placeRepository.findById(placeId).orElseThrow(()->new RuntimeException("Place not found"));
        if(place.isOccupied()) throw new RuntimeException("Place already occupied");
        place.setOccupied(true);
        placeRepository.save(place);

        Reservation r = new Reservation();
        r.setPlate(plate);
        r.setStartTime(LocalDateTime.now());
        r.setPlace(place);
        return reservationRepository.save(r);
    }

    public Reservation finish(Long id) {
        Reservation r = reservationRepository.findById(id).orElseThrow(()->new RuntimeException("Reservation not found"));
        r.setEndTime(LocalDateTime.now());
        Place p = r.getPlace();
        p.setOccupied(false);
        placeRepository.save(p);
        return reservationRepository.save(r);
    }
}
