package edu.university.parking.service;

import edu.university.parking.model.Place;
import edu.university.parking.repository.PlaceRepository;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;

@Service
public class PlaceService {
    private final PlaceRepository repo;

    public PlaceService(PlaceRepository repo) {
        this.repo = repo;
    }

    @PostConstruct
    public void init() {
        if(repo.count()==0){
            repo.save(new Place("A1", false));
            repo.save(new Place("A2", false));
            repo.save(new Place("B1", false));
        }
    }

    public List<Place> listAll() {
        return repo.findAll();
    }

    public Place get(Long id) {
        return repo.findById(id).orElse(null);
    }

    public Place save(Place p) {
        return repo.save(p);
    }
}
