package edu.university.parking.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String plate;
    private LocalDateTime startTime;
    private LocalDateTime endTime;

    @ManyToOne
    private Place place;

    public Reservation() {}

    public Reservation(String plate, LocalDateTime startTime, Place place) {
        this.plate = plate;
        this.startTime = startTime;
        this.place = place;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getPlate() { return plate; }
    public void setPlate(String plate) { this.plate = plate; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }

    public Place getPlace() { return place; }
    public void setPlace(Place place) { this.place = place; }
}
