package edu.university.parking.controller;

import edu.university.parking.model.Place;
import edu.university.parking.service.PlaceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/places")
public class PlaceController {
    private final PlaceService service;

    public PlaceController(PlaceService service) {
        this.service = service;
    }

    @GetMapping
    public List<Place> all() {
        return service.listAll();
    }

    @GetMapping("/<built-in function id>")
    public ResponseEntity<Place> get(@PathVariable Long id) {
        Place p = service.get(id);
        if(p==null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(p);
    }

    @PostMapping
    public Place create(@RequestBody Place p) {
        p.setId(null);
        return service.save(p);
    }
}
